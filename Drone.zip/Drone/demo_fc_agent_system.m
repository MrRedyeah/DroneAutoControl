%% 无人机飞控代码自动迭代系统演示
% 演示如何使用完整的Agent系统

clear; clc; close all;

%% 1. 系统初始化
fprintf('🚀 初始化无人机飞控代码自动迭代系统...\n');

% 设置项目路径和模型路径
project_path = 'D:\OneDrive\Desktop\FC_Project';  % 飞控项目路径
model_path = 'D:\OneDrive\Desktop\FC_Project\drone_model.slx';  % Simulink模型路径

% 创建系统实例
fc_system = DroneFCAgentSystem(project_path, model_path);

%% 2. 运行多轮迭代
fprintf('\n🔄 开始自动迭代优化...\n');

num_iterations = 10;  % 迭代次数
all_results = {};

for iter = 1:num_iterations
    fprintf('\n' + repmat('=', 1, 60) + '\n');
    fprintf('第 %d/%d 轮迭代\n', iter, num_iterations);
    fprintf(repmat('=', 1, 60) + '\n');

    try
        % 运行单次迭代
        [fc_system, results] = fc_system.run_iteration();
        all_results{end+1} = results;

        % 显示当前性能
        fprintf('当前性能指标:\n');
        fprintf('  姿态误差: %.3f° (目标: <%.1f°)\n', results.metrics(1), fc_system.config.targets.max_attitude_error);
        fprintf('  控制延迟: %.3f秒 (目标: <%.3f秒)\n', results.metrics(2), fc_system.config.targets.max_control_latency);
        fprintf('  稳定性余量: %.3f (目标: >%.1f)\n', results.metrics(3), fc_system.config.targets.min_stability_margin);
        fprintf('  能耗: %.1f瓦时\n', results.metrics(4));
        fprintf('  奖励值: %.2f\n', results.reward);

        % 检查是否达到目标
        if results.metrics(1) < fc_system.config.targets.max_attitude_error && ...
           results.metrics(2) < fc_system.config.targets.max_control_latency && ...
           results.metrics(3) > fc_system.config.targets.min_stability_margin
            fprintf('🎉 恭喜！已达到性能目标，可以提前终止优化\n');
            break;
        end

        % 暂停一下，模拟实际运行
        if iter < num_iterations
            fprintf('准备下一轮迭代...\n');
            pause(1);
        end

    catch err
        fprintf('❌ 第 %d 轮迭代失败: %s\n', iter, err.message);
        break;
    end
end

%% 3. 生成最终报告
fprintf('\n' + repmat('=', 1, 60) + '\n');
fc_system.generate_report();

%% 4. 性能对比分析
if length(all_results) >= 2
    fprintf('\n📈 性能改进分析:\n');

    initial_metrics = all_results{1}.metrics;
    final_metrics = all_results{end}.metrics;

    improvement_attitude = (initial_metrics(1) - final_metrics(1)) / initial_metrics(1) * 100;
    improvement_latency = (initial_metrics(2) - final_metrics(2)) / initial_metrics(2) * 100;
    improvement_stability = (final_metrics(3) - initial_metrics(3)) / initial_metrics(3) * 100;

    fprintf('  姿态误差改进: %.1f%%\n', improvement_attitude);
    fprintf('  控制延迟改进: %.1f%%\n', improvement_latency);
    fprintf('  稳定性改进: %.1f%%\n', improvement_stability);

    total_tokens = sum([fc_system.iteration_history.token_usage]);
    fprintf('  总Token使用量: %.1fK\n', total_tokens/1000);
end

%% 5. 保存优化结果
fprintf('\n💾 保存优化结果...\n');

% 创建结果结构
optimization_results = struct();
optimization_results.system = fc_system;
optimization_results.iteration_history = fc_system.iteration_history;
optimization_results.final_performance = all_results{end};
optimization_results.optimization_date = datestr(now);

% 保存到文件
save_file = sprintf('fc_optimization_results_%s.mat', datestr(now, 'yyyymmdd_HHMMSS'));
save(save_file, 'optimization_results');

fprintf('✅ 优化结果已保存到: %s\n', save_file);

%% 6. 可视化结果
fprintf('\n📊 生成可视化图表...\n');
fc_system.plot_performance_trend();

% 保存图表
gcf_handle = gcf;
saveas(gcf_handle, 'performance_trend.png');

fprintf('✅ 图表已保存为: performance_trend.png\n');

%% 7. 部署建议
fprintf('\n🚀 部署建议:\n');
final_metrics = all_results{end}.metrics;

if final_metrics(1) < fc_system.config.targets.max_attitude_error
    fprintf('✅ 姿态控制性能达标，可以直接部署\n');
else
    fprintf('⚠️  姿态控制仍有改进空间，建议继续优化\n');
end

if final_metrics(2) < fc_system.config.targets.max_control_latency
    fprintf('✅ 控制延迟性能达标\n');
else
    fprintf('⚠️  控制延迟需要进一步优化\n');
end

if final_metrics(3) > fc_system.config.targets.min_stability_margin
    fprintf('✅ 系统稳定性良好\n');
else
    fprintf('⚠️  系统稳定性需要加强\n');
end

fprintf('\n🎯 优化完成！\n');